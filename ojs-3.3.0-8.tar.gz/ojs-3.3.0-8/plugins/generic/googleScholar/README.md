# googleScholar
Exposes OJS and OPS metadata to Google Scholar for harvesting.

This plugin is included in compatible OJS and OPS releases; please do not install it manually.
